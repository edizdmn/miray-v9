MIRAY VS AILE V8 - Seviye Butonları Kesin Sürüm

Bu sürümde:
- Ana menüde KOLAY / ORTA / ZOR butonları kesin görünür.
- Kolay mod çok yavaş başlar.
- Orta dengeli başlar.
- Zor hızlı başlar.
- Menü altında V8 yazısı görünür; böylece doğru sürümü kurduğunu anlarsın.

GitHub'a yükleme:
1) ZIP'i çıkar.
2) İçindeki app klasörü, build.gradle ve settings.gradle dosyasını GitHub'a yükle.
3) Commit changes de.
4) Actions yeşil tik olunca Artifacts > Miray-vs-Aile-APK indir.
5) Telefonda eski Miray vs Aile uygulamasını kaldırıp yeni APK'yı kur.
